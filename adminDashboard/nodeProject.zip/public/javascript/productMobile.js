  const menuBtn = document.getElementById("mobile-menu-product");
  const menu = document.getElementById("mobile-product");

  menuBtn.addEventListener("click", () => {
    menu.classList.toggle("hidden");
  });

