const { default: mongoose } = require("mongoose");
require('dotenv').config(); 

const dbURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/durgagrocery';

// Export a function that handles the connection logic
const connectDB = async () => {
    try {
        await mongoose.connect(dbURI, {
            // Options that can help stability in AWS/cloud environments
            serverSelectionTimeoutMS: 15000, // Increase server selection timeout to 15 seconds
            socketTimeoutMS: 45000, // Increase socket timeout to 45 seconds
        });
        console.log("Mongoose connected successfully!");
    } catch (err) {
        console.error("Mongoose connection failed:", err.message);
        // Exiting the process on connection failure is standard practice
        process.exit(1); 
    }
};

module.exports = connectDB; // Export the function