function swapImages(arr) {
    // your logic here
    return arr.reverse(); 
}

module.exports = swapImages;