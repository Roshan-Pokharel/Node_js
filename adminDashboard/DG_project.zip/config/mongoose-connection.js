const { default: mongoose } = require("mongoose");
require('dotenv').config(); // Ensure dotenv is loaded if running locally

// Use environment variable or fallback to local for testing
const dbURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/durgagrocery';

mongoose.connect(dbURI).then(() => {
    console.log("Mongoose connected successfully");
}).catch((err) => {
    console.log("Mongoose connection failed:", err);
});