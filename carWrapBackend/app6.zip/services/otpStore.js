const otpStore = {};
module.exports = otpStore;
